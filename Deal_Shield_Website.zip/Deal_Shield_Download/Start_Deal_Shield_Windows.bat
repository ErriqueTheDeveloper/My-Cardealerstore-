@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  echo Open http://localhost:8080/ in your browser. Keep this window open.
  py -m http.server 8080 --directory dist
) else (
  echo Python was not found. Install Python from https://www.python.org/downloads/ and try again.
  pause
)
